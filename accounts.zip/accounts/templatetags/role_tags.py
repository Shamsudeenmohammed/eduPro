"""
accounts/templatetags/role_tags.py

Custom template tags and filters for role-based rendering in templates.

Usage:
    {% load role_tags %}
    {% if request.user|is_admin %}...{% endif %}
    {% if request.user|has_role:"teacher" %}...{% endif %}
"""

from django import template

from accounts.models import Role

register = template.Library()


@register.filter(name="is_admin")
def is_admin(user):
    """Return True if the user has the ADMIN role or is a Django superuser."""
    return getattr(user, "role", None) == Role.ADMIN or getattr(user, "is_superuser", False)


@register.filter(name="is_teacher")
def is_teacher(user):
    """Return True if the user has the TEACHER role."""
    return getattr(user, "role", None) == Role.TEACHER


@register.filter(name="is_student")
def is_student(user):
    """Return True if the user has the STUDENT role."""
    return getattr(user, "role", None) == Role.STUDENT


@register.filter(name="has_role")
def has_role(user, role_name: str):
    """
    Generic role check.
    Usage: {{ user|has_role:"teacher" }}
    Accepts comma-separated roles: {{ user|has_role:"admin,teacher" }}
    """
    roles = [r.strip().lower() for r in role_name.split(",")]
    user_role = getattr(user, "role", "").lower()
    return user_role in roles or getattr(user, "is_superuser", False)


@register.simple_tag(takes_context=True)
def active_if(context, *url_names):
    """
    Returns 'active' CSS class string if the current URL name matches.
    Usage: {% active_if "accounts:profile" "accounts:change_password" %}
    """
    request = context.get("request")
    if request is None:
        return ""
    current = request.resolver_match.view_name if request.resolver_match else ""
    return "active" if current in url_names else ""
