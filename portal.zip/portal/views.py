"""
portal/views.py

Admissions portal views for eduPro.

Public views (no login required):
    application_form      — prospective students submit an application
    application_status    — check application status by reference number
    application_confirmed — success page after submission
    application_withdrawn — applicant withdraws own application

Staff-only views:
    admissions_dashboard  — admissions officer / admin overview
    application_list      — paginated list with status filter
    application_detail    — full detail view + action buttons
    application_review    — mark as REVIEWING
    application_approve   — approve + provision EduProUser
    application_reject    — reject with reason
    document_request_create — request additional docs from applicant
    document_request_fulfill — mark a document request fulfilled

Access control:
    - Admissions officers: responsibility_required(ADMISSIONS_OFFICER)
    - Admin: admin_required
    - Both: the mixin _admissions_or_admin_required handles this cleanly.
"""

from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.core.exceptions import ValidationError
from django.core.paginator import Paginator
from django.shortcuts import get_object_or_404, redirect, render
from django.views.decorators.http import require_http_methods
from django.db import models, transaction

from accounts.decorators import admin_required, responsibility_required
from accounts.models import StaffResponsibility

from .forms import (
    AdmissionApplicationForm,
    ApplicationRejectForm,
    ApplicationReviewForm,
    ApplicationStatusCheckForm,
    DocumentRequestForm,
)
from .models import AdmissionApplication, AdmissionCycle, AdmissionStatus, DocumentRequest


# ─────────────────────────────────────────────────────────────────────────────
# INTERNAL HELPERS
# ─────────────────────────────────────────────────────────────────────────────

# portal/views.py

from django.shortcuts import render

from .models import AdmissionCycle, AdmissionApplication

def home(request):
    """
    Public landing page for eduPro.
    """

    # Temporary placeholder until Announcement model exists
    announcements = []

    context = {
        "site_name": "eduPro",
        "announcements": announcements,
    }

    return render(request, "portal/home.html", context)


def _is_admissions_staff(user):
    """True if user is admin/superuser OR holds ADMISSIONS_OFFICER responsibility."""
    return (
        user.is_authenticated
        and (
            user.is_admin
            or user.is_superuser
            or user.has_responsibility(StaffResponsibility.ADMISSIONS_OFFICER)
        )
    )


def _admissions_required(view_func):
    """
    Combined decorator: admits ADMIN and ADMISSIONS_OFFICER.
    Used instead of stacking two decorators on every view.
    """
    from functools import wraps
    from django.shortcuts import redirect as _redirect

    @wraps(view_func)
    def wrapper(request, *args, **kwargs):
        if not request.user.is_authenticated:
            return _redirect(f"/accounts/login/?next={request.path}")
        if _is_admissions_staff(request.user):
            return view_func(request, *args, **kwargs)
        messages.error(request, "Admissions officer or administrator access required.")
        return _redirect(request.user.get_dashboard_url())

    return wrapper


# ─────────────────────────────────────────────────────────────────────────────
# PUBLIC VIEWS
# ─────────────────────────────────────────────────────────────────────────────

@require_http_methods(["GET", "POST"])
def application_form(request):
    """
    Public application form.
    Authenticated users who are already students are redirected.
    Applicants do NOT need an account to apply.
    """
    if request.user.is_authenticated and request.user.is_student:
        messages.info(request, "You already have a student account.")
        return redirect(request.user.get_dashboard_url())

    active_cycle = AdmissionCycle.get_active()
    if not active_cycle or not active_cycle.is_open:
        return render(request, "portal/admissions_closed.html", {
            "page_title": "Admissions Closed",
            "cycle":      active_cycle,
        })

    form = AdmissionApplicationForm(
        cycle=active_cycle,
        data=request.POST or None,
        files=request.FILES or None,
    )

    if request.method == "POST" and form.is_valid():
        application = form.save(commit=False)
        application.cycle = active_cycle
        application.save()
        return redirect("portal:application_confirmed", ref=application.reference_number)

    return render(request, "portal/application_form.html", {
        "page_title": "Apply for Admission",
        "form":       form,
        "cycle":      active_cycle,
    })


def application_confirmed(request, ref):
    """Success page shown immediately after a new application is submitted."""
    application = get_object_or_404(AdmissionApplication, reference_number=ref)
    return render(request, "portal/application_confirmed.html", {
        "page_title":  "Application Submitted",
        "application": application,
        "ref":         ref,
    })


@require_http_methods(["GET", "POST"])
def application_status(request):
    """
    Public status-check page.
    Applicant enters their reference number + email to check progress.
    """
    form = ApplicationStatusCheckForm(request.POST or None)
    application = None

    if request.method == "POST" and form.is_valid():
        ref   = form.cleaned_data["reference_number"]
        email = form.cleaned_data["email"]
        try:
            application = AdmissionApplication.objects.get(
                reference_number__iexact=ref,
                email__iexact=email,
            )
        except AdmissionApplication.DoesNotExist:
            messages.error(
                request,
                "No application found with that reference number and email. "
                "Please double-check and try again."
            )

    return render(request, "portal/application_status.html", {
        "page_title":  "Check Application Status",
        "form":        form,
        "application": application,
    })


@require_http_methods(["POST"])
def application_withdraw(request, ref):
    """Applicant withdraws their own application (by reference number)."""
    application = get_object_or_404(AdmissionApplication, reference_number=ref)
    try:
        application.withdraw()
        messages.info(
            request,
            f"Application {ref} has been withdrawn. "
            "Contact the admissions office if this was a mistake."
        )
    except ValidationError as e:
        messages.error(request, str(e.message))
    return redirect("portal:application_status")


# ─────────────────────────────────────────────────────────────────────────────
# STAFF VIEWS — ADMISSIONS DASHBOARD
# ─────────────────────────────────────────────────────────────────────────────

@login_required
@_admissions_required
def admissions_dashboard(request):
    """
    Admissions officer / admin overview:
    - counts by status
    - recent pending applications
    - active cycle info
    """
    active_cycle = AdmissionCycle.get_active()
    cycle_qs     = (
        AdmissionApplication.objects.filter(cycle=active_cycle)
        if active_cycle else AdmissionApplication.objects.none()
    )

    status_counts = {
        "pending":   cycle_qs.filter(status=AdmissionStatus.PENDING).count(),
        "reviewing": cycle_qs.filter(status=AdmissionStatus.REVIEWING).count(),
        "approved":  cycle_qs.filter(status=AdmissionStatus.APPROVED).count(),
        "rejected":  cycle_qs.filter(status=AdmissionStatus.REJECTED).count(),
        "withdrawn": cycle_qs.filter(status=AdmissionStatus.WITHDRAWN).count(),
        "total":     cycle_qs.count(),
    }

    recent_pending = (
        cycle_qs
        .filter(status=AdmissionStatus.PENDING)
        .select_related("program_applied__department")
        .order_by("-created_at")[:8]
    )

    return render(request, "portal/admissions_dashboard.html", {
        "page_title":    "Admissions Dashboard",
        "active_cycle":  active_cycle,
        "status_counts": status_counts,
        "recent_pending": recent_pending,
    })


@login_required
@_admissions_required
def application_list(request):
    """Paginated list of all applications with status and cycle filtering."""
    qs = (
        AdmissionApplication.objects
        .select_related("cycle", "program_applied__department", "reviewed_by", "approved_by")
        .order_by("-created_at")
    )

    # Filters
    status_filter = request.GET.get("status", "")
    cycle_filter  = request.GET.get("cycle",  "")
    search_query  = request.GET.get("q",      "").strip()

    if status_filter:
        qs = qs.filter(status=status_filter)
    if cycle_filter:
        qs = qs.filter(cycle__id=cycle_filter)
    if search_query:
        qs = qs.filter(
            models.Q(first_name__icontains=search_query)
            | models.Q(last_name__icontains=search_query)
            | models.Q(email__icontains=search_query)
            | models.Q(reference_number__icontains=search_query)
        )

    paginator = Paginator(qs, 20)
    page_obj  = paginator.get_page(request.GET.get("page"))

    return render(request, "portal/application_list.html", {
        "page_title":     "Applications",
        "page_obj":       page_obj,
        "status_choices": AdmissionStatus.choices,
        "cycles":         AdmissionCycle.objects.order_by("-start_date"),
        "status_filter":  status_filter,
        "cycle_filter":   cycle_filter,
        "search_query":   search_query,
    })


@login_required
@_admissions_required
def application_detail(request, pk):
    """Full application detail with inline document requests."""
    application = get_object_or_404(
        AdmissionApplication.objects.select_related(
            "cycle", "program_applied__department",
            "reviewed_by", "approved_by", "rejected_by", "user",
        ),
        pk=pk,
    )
    doc_requests = application.document_requests.select_related("requested_by").order_by("-requested_at")

    return render(request, "portal/application_detail.html", {
        "page_title":    f"Application — {application.get_full_name()}",
        "application":   application,
        "doc_requests":  doc_requests,
        "AdmissionStatus": AdmissionStatus,
    })


@login_required
@_admissions_required
@require_http_methods(["POST"])
def application_review(request, pk):
    """Mark a PENDING application as REVIEWING."""
    application = get_object_or_404(AdmissionApplication, pk=pk)
    try:
        application.mark_reviewing(request.user)
        messages.info(
            request,
            f"Application {application.reference_number} is now marked as Under Review."
        )
    except ValidationError as e:
        messages.error(request, str(e.message))
    return redirect("portal:application_detail", pk=pk)


@login_required
@_admissions_required
@require_http_methods(["GET", "POST"])
def application_approve(request, pk):
    """
    Approve an application and provision the EduProUser account.

    GET:  shows a confirmation page with summary.
    POST: calls application.approve(actor) → creates/links EduProUser.
    """
    application = get_object_or_404(
        AdmissionApplication.objects.select_related("program_applied", "cycle"),
        pk=pk,
    )

    if application.status not in (AdmissionStatus.PENDING, AdmissionStatus.REVIEWING):
        messages.warning(
            request,
            f"This application is already {application.get_status_display()} "
            "and cannot be approved again."
        )
        return redirect("portal:application_detail", pk=pk)

    if request.method == "POST":
        review_notes = request.POST.get("review_notes", "")
        try:
            new_user = application.approve(actor=request.user)
            if review_notes:
                application.review_notes = review_notes
                application.save(update_fields=["review_notes"])

            messages.success(
                request,
                f"Application approved. User account created for "
                f"{new_user.get_full_name()} ({new_user.email}). "
                f"They can now log in after setting a password."
            )
        except ValidationError as e:
            messages.error(request, str(e.message))
            return redirect("portal:application_detail", pk=pk)

        return redirect("portal:application_detail", pk=pk)

    return render(request, "portal/application_approve_confirm.html", {
        "page_title":  "Approve Application",
        "application": application,
    })


@login_required
@_admissions_required
@require_http_methods(["GET", "POST"])
def application_reject(request, pk):
    """Reject an application with a mandatory reason."""
    application = get_object_or_404(AdmissionApplication, pk=pk)

    if application.status in (AdmissionStatus.APPROVED, AdmissionStatus.WITHDRAWN):
        messages.warning(
            request,
            f"Cannot reject an already {application.get_status_display()} application."
        )
        return redirect("portal:application_detail", pk=pk)

    form = ApplicationRejectForm(request.POST or None)

    if request.method == "POST" and form.is_valid():
        try:
            application.reject(
                actor=request.user,
                reason=form.cleaned_data["rejection_reason"],
            )
            messages.info(
                request,
                f"Application {application.reference_number} rejected."
            )
        except ValidationError as e:
            messages.error(request, str(e.message))
        return redirect("portal:application_detail", pk=pk)

    return render(request, "portal/application_reject_form.html", {
        "page_title":  "Reject Application",
        "application": application,
        "form":        form,
    })


# ─────────────────────────────────────────────────────────────────────────────
# DOCUMENT REQUEST VIEWS
# ─────────────────────────────────────────────────────────────────────────────

@login_required
@_admissions_required
@require_http_methods(["GET", "POST"])
def document_request_create(request, application_pk):
    """Admissions officer requests a missing document from the applicant."""
    application = get_object_or_404(AdmissionApplication, pk=application_pk)
    form = DocumentRequestForm(request.POST or None)

    if request.method == "POST" and form.is_valid():
        doc_req = form.save(commit=False)
        doc_req.application  = application
        doc_req.requested_by = request.user
        doc_req.save()
        messages.success(
            request,
            f"Document request '{doc_req.document_name}' created. "
            "Applicant should be notified separately."
        )
        return redirect("portal:application_detail", pk=application_pk)

    return render(request, "portal/document_request_form.html", {
        "page_title":  "Request Document",
        "application": application,
        "form":        form,
    })


@login_required
@_admissions_required
@require_http_methods(["POST"])
def document_request_fulfill(request, pk):
    """Mark a document request as fulfilled."""
    doc_req = get_object_or_404(DocumentRequest, pk=pk)
    doc_req.mark_fulfilled()
    messages.success(request, f"Document request '{doc_req.document_name}' marked as fulfilled.")
    return redirect("portal:application_detail", pk=doc_req.application_id)


# ─────────────────────────────────────────────────────────────────────────────
# ADMIN-ONLY: CYCLE MANAGEMENT
# ─────────────────────────────────────────────────────────────────────────────

@login_required
@admin_required
def cycle_list(request):
    cycles = AdmissionCycle.objects.order_by("-start_date")
    return render(request, "portal/cycle_list.html", {
        "page_title": "Admission Cycles",
        "cycles":     cycles,
    })


@login_required
@admin_required
@require_http_methods(["GET", "POST"])
def cycle_create(request):
    from .forms import AdmissionCycleForm
    form = AdmissionCycleForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        form.save()
        messages.success(request, "Admission cycle created.")
        return redirect("portal:cycle_list")
    return render(request, "portal/cycle_form.html", {
        "page_title": "New Admission Cycle",
        "form":       form,
    })


@login_required
@admin_required
@require_http_methods(["GET", "POST"])
def cycle_edit(request, pk):
    from .forms import AdmissionCycleForm
    cycle = get_object_or_404(AdmissionCycle, pk=pk)
    form  = AdmissionCycleForm(request.POST or None, instance=cycle)
    if request.method == "POST" and form.is_valid():
        form.save()
        messages.success(request, "Admission cycle updated.")
        return redirect("portal:cycle_list")
    return render(request, "portal/cycle_form.html", {
        "page_title": "Edit Admission Cycle",
        "form":       form,
        "cycle":      cycle,
    })


# Avoid F821 (models not imported at top level in this module)
try:
    from django.db import models as _djmodels
except ImportError:
    pass
