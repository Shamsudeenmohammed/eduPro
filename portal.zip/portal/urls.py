"""
portal/urls.py

All URL patterns for the admissions portal.
Include in main urls.py as:
    path("portal/", include("portal.urls", namespace="portal")),
"""

from django.urls import path

from . import views

app_name = "portal"

urlpatterns = [
    path("", views.home, name="home"),
    # ── Public views ──────────────────────────────────────────────────────────
    path("apply/",                              views.application_form,      name="apply"),
    path("apply/confirmed/<str:ref>/",          views.application_confirmed,  name="application_confirmed"),
    path("status/",                             views.application_status,     name="application_status"),
    path("status/<str:ref>/withdraw/",          views.application_withdraw,   name="application_withdraw"),

    # ── Staff: dashboard & list ───────────────────────────────────────────────
    path("admissions/",                         views.admissions_dashboard,   name="admissions_dashboard"),
    path("admissions/applications/",            views.application_list,       name="application_list"),

    # ── Staff: application detail & actions ───────────────────────────────────
    path("admissions/applications/<int:pk>/",             views.application_detail,  name="application_detail"),
    path("admissions/applications/<int:pk>/review/",      views.application_review,  name="application_review"),
    path("admissions/applications/<int:pk>/approve/",     views.application_approve, name="application_approve"),
    path("admissions/applications/<int:pk>/reject/",      views.application_reject,  name="application_reject"),

    # ── Staff: document requests ──────────────────────────────────────────────
    path(
        "admissions/applications/<int:application_pk>/request-doc/",
        views.document_request_create,
        name="document_request_create",
    ),
    path(
        "admissions/doc-requests/<int:pk>/fulfill/",
        views.document_request_fulfill,
        name="document_request_fulfill",
    ),

    # ── Admin: admission cycles ───────────────────────────────────────────────
    path("admissions/cycles/",               views.cycle_list,   name="cycle_list"),
    path("admissions/cycles/add/",           views.cycle_create, name="cycle_create"),
    path("admissions/cycles/<int:pk>/edit/", views.cycle_edit,   name="cycle_edit"),
]
